from flask import Flask, render_template, abort
from DbClass import DbClass
app = Flask(__name__)


@app.route('/')
def index():
    try:
        return render_template("index.html")
    except:
        abort(404)

@app.route('/realtime')
def realtime():
    try:
        return render_template("realtime.html")
    except:
        abort(404)

@app.route('/geschiedenis')
def geschiedenis():
    try:
        return render_template("geschiedenis.html")
    except:
        abort(404)

if __name__ == '__main__':
    app.run()
