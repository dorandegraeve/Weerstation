class DbClass:
    def __init__(self):
        import mysql.connector as connector

        self.__dsn = {
            "host": "Localhost",
            "user": "root",
            "passwd": "root",
            "db": "weerstation"
        }

        self.__connection = connector.connect(**self.__dsn)
        self.__cursor = self.__connection.cursor()

    def getLatestTemperature(self):
        # Query zonder parameters
        sqlQuery = "SELECT Temperatuur FROM Soort_Meting ORDER BY ID DESC LIMIT 1"
        self.__connection.reset_session()
        cursor = self.__connection.cursor()
        cursor.execute(sqlQuery)
        result = cursor.fetchall()
        temperature = result
        temperature = str(temperature).split(',')
        temperature = temperature[0]
        temperature = temperature[2:]
        cursor.close()
        return temperature

    def getLatestHumidity(self):
        # Query zonder parameters
        sqlQuery = "SELECT Luchtvochtigheid FROM Soort_Meting ORDER BY ID DESC LIMIT 1"
        cursor = self.__connection.cursor()
        cursor.execute(sqlQuery)
        result = cursor.fetchall()
        humidity = result
        humidity = str(humidity).split(',')
        humidity = humidity[0]
        humidity = humidity[2:]
        cursor.close()
        return humidity

    def getLatestPressure(self):
        # Query zonder parameters
        sqlQuery = "SELECT Luchtdruk FROM Soort_Meting ORDER BY ID DESC LIMIT 1"
        cursor = self.__connection.cursor()
        cursor.execute(sqlQuery)
        result = cursor.fetchall()
        pressure = result
        pressure = str(pressure).split(',')
        pressure = pressure[0]
        pressure = pressure[2:]
        cursor.close()
        return pressure

    def getLatestRainsensor(self):
        # Query zonder parameters
        sqlQuery = "SELECT Neerslag FROM Soort_Meting ORDER BY ID DESC LIMIT 1"
        cursor = self.__connection.cursor()
        cursor.execute(sqlQuery)
        result = cursor.fetchall()
        rain = result
        rain = str(rain).split(',')
        rain = rain[0]
        rain = rain[2:]
        if int(rain) == 0:
            rain = "Regen"
        elif int(rain) == 1:
            rain = "Lichte regen"
        elif int(rain) == 2:
            rain = "Geen regen"
        cursor.close()
        return rain

    def getDataFromDatabase(self):
        # Query zonder parameters
        sqlQuery = "SELECT * FROM tablename"
        
        self.__cursor.execute(sqlQuery)
        result = self.__cursor.fetchall()
        self.__cursor.close()
        return result

    def getDataFromDatabaseMetVoorwaarde(self, voorwaarde):
        # Query met parameters
        sqlQuery = "SELECT * FROM tablename WHERE columnname = '{param1}'"
        # Combineren van de query en parameter
        sqlCommand = sqlQuery.format(param1=voorwaarde)
        
        self.__cursor.execute(sqlCommand)
        result = self.__cursor.fetchall()
        self.__cursor.close()
        return result

    def setDataToDatabase(self, value1):
        # Query met parameters
        sqlQuery = "INSERT INTO tablename (columnname) VALUES ('{param1}')"
        # Combineren van de query en parameter
        sqlCommand = sqlQuery.format(param1=value1)

        self.__cursor.execute(sqlCommand)
        self.__connection.commit()
        self.__cursor.close()