import serial
import MySQLdb as mdb

arduino = serial.Serial("/dev/ttyUSB0")
arduino.baudrate=9600

data = arduino.readline()
pieces = data.split(":")

temperature = pieces[0]
humidity = pieces[1]
pressure = pieces[2]
rain = pieces[3]

con = mdb.connect('localhost', 'root', 'root', 'weerstation');

with con:

        cursor = con.cursor()
        cursor.execute('''INSERT INTO Soort_Meting(Temperatuur,Luchtvochtigheid,Luchtdruk,Neerslag) VALUES(%s,%s,%s,%s)''', (temperature, humidity, pressure, rain))
        con.commit()
        cursor.close()