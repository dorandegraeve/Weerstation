import mysql.connector as mc

connection = mc.connect (host = "local",
                         user = "doran",
                         passwd = "doran",
                         db = "weerstationdb")

cursor = connection.cursor()
cursor.execute("SELECT * FROM Test")
result = cursor.fetchall()
for r in result:
    print (r)

cursor.close()
connection.close()