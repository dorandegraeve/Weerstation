from flask import Flask, render_template, abort
import os
from DbClass import DbClass
app = Flask(__name__)

mysql = DbClass()

@app.route('/')
def index():
    try:
        return render_template("index.html")
    except:
        abort(404)

@app.route('/realtime')
def realtime():
    try:
        temp = mysql.getLatestTemperature()
        hum = mysql.getLatestHumidity()
        rain = mysql.getLatestRainsensor()
        pres = mysql.getLatestPressure()
        return render_template("realtime.html", temperatuur = temp, luchtvochtigheid = hum, regen = rain, luchtdruk = pres)
    except:
        abort(404)

# @app.route('/geschiedenis')
# def geschiedenis():
#     try:
#         return render_template("geschiedenis.html")
#     except:
#         abort(404)

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8080))
    host = "0.0.0.0"
    app.run(host=host, port=port, debug=True)
