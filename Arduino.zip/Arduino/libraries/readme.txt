Ga naar http://www.arduino.cc/en/Guide/Libraries voor meer informatie over het installeren van bibliotheken
